package com.comment.exceptions;

public class NoCommentException extends Exception {
	
	public NoCommentException(String message) 
	{
		System.out.println(message);
	}

}
