package com.comment.exceptions;

public class InValidNameException extends Exception{
	public InValidNameException(String message) {
		System.out.println(message);
		// TODO Auto-generated constructor stub
	}

}
