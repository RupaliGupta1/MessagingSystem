package com.comment.dto;

public class SentComments
{
	 private String commentTo;
	    private String message;
	    private String commentDateTime;
		public String getCommentTo() {
			return commentTo;
		}
		public void setCommentTo(String commentTo) {
			this.commentTo = commentTo;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		public String getCommentDateTime() {
			return commentDateTime;
		}
		public void setCommentDateTime(String commentDateTime) {
			this.commentDateTime = commentDateTime;
		}
		public SentComments() {
			// TODO Auto-generated constructor stub
		}
	    
	    

}
