package com.comment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessagingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
